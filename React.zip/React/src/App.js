import React from 'react';
import './App.css';
import Item from './components/Item';

function App() {
    return (
        <div className="App">
            <h1>7 смертных грехов</h1>
            <Item />
        </div>
    );
}

export default App;